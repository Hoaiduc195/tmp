#include "function.h"
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    TamGiac t;
    ToaDo trongtam;

    cout<<"Nhap cac diem A, B, C cua tam giac"; 
    nhapTamGiac(t);
    trongtam = tinhTrongTam(t);

    cout<<"Chu vi cua tam giac:"<<chuVi(t);
    cout<<endl;

    cout<<"Trong tam cua tam giac la diem:";
    xuatToaDo(trongtam);
    cout<<endl;

    return 0;
}