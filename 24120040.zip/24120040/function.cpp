#include <iostream>
#include <cmath>

using namespace std;

struct ToaDo
{
    double x;
    double y;
};

struct TamGiac
{
    ToaDo A;
    ToaDo B;
    ToaDo C;

};

void nhapToaDo(ToaDo &a)
{
    cin>>a.x>>a.y;

}

void xuatToaDo(ToaDo a)
{
    cout<<"("<<a.x<<";"<<a.y<<")"<<endl;
}

double tinhKhoangCach(ToaDo a, ToaDo b)
{
    
    return sqrt(pow(a.x-b.x,2.0) + pow(a.y-b.y,2.0));

}

void nhapTamGiac(TamGiac &t)
{
    nhapToaDo(t.A);
    nhapToaDo(t.B);
    nhapToaDo(t.C);
    
}

double chuVi(TamGiac t)
{
    double canh1 = tinhKhoangCach(t.A,t.B);
    double canh2 = tinhKhoangCach(t.C,t.B);
    double canh3 = tinhKhoangCach(t.A,t.C);

    return canh1 + canh2 + canh3;
}

ToaDo tinhTrongTam(TamGiac t)
{
    ToaDo trongTam ;

    trongTam.x = (1/3)*(t.A.x+t.B.x+t.C.x);
    trongTam.y = (1/3)*(t.A.y+t.B.y+t.C.y);

    return trongTam;
}


