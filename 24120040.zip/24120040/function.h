#ifndef FUNCTION
#define FUNCTION


struct ToaDo
{
    double x;
    double y;
};

struct TamGiac
{
    ToaDo A;
    ToaDo B;
    ToaDo C;

};

void nhapToaDo(ToaDo &a);
void xuatToaDo(ToaDo a);
double tinhKhoangCach(ToaDo a, ToaDo b);
void nhapTamGiac(TamGiac &t);
double chuVi(TamGiac t);
ToaDo tinhTrongTam(TamGiac t);

#endif